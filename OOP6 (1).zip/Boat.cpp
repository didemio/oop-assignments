﻿#include "Boat.hpp"
#include "utilities.hpp"

Boat::Boat(int id, std::shared_ptr<BoatSpec> spec, std::chrono::year_month_day date, bool sold)
    : _id(id), _spec(spec), _date_purchased(date), _sold(sold) {
}

std::shared_ptr<AbstractionSpec> Boat::get_spec() const { return _spec; }
int Boat::get_id() const { return _id; }
bool Boat::get_sold() const { return _sold; }
std::chrono::year_month_day Boat::get_date_purchased() const { return _date_purchased; }

bool Boat::matches(const AbstractionSpec& spec) const
{
    const auto& boat_spec = dynamic_cast<const BoatSpec&>(spec);
    return _spec->matches(boat_spec);
}

void Boat::send_to(std::ostream& os) const
{
    os << _id << csv_delimiter
        << to_string(_date_purchased) << csv_delimiter
        << _sold << csv_delimiter;

    if (_spec)
        _spec->send_to(os);
    else
        BoatSpec().send_to(os);
}

void Boat::recv_from(std::istream& is)
{
    is >> _id;
    is.ignore();

    std::string date_str;
    std::getline(is, date_str, csv_delimiter);
    _date_purchased = from_string(date_str);

    is >> _sold;
    is.ignore();

    auto temp_spec = std::make_shared<BoatSpec>();
    temp_spec->recv_from(is);
    _spec = temp_spec;
}
