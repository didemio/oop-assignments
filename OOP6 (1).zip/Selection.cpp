﻿#include "Selection.hpp"
#include "Boat.hpp"

const Abstraction& Selection::search(const AbstractionSpec& spec)
{
    for (const auto& item : items_)
    {
        if (item->matches(spec))
            return *item;
    }
    throw std::runtime_error("Item not found");
}

const Abstraction& Selection::search(int id)
{
    for (const auto& item : items_)
    {
        if (item->get_id() == id)
            return *item;
    }
    throw std::runtime_error("Item not found");
}

void Selection::save(const std::string& csv_file_name) const
{
    std::ofstream file_out(csv_file_name);
    if (!file_out)
        throw std::runtime_error("Failed to open file for saving.");

    for (const auto& item : items_)
    {
        file_out << *item << '\n';
    }
}

void Selection::load(const std::string& csv_file_name)
{
    std::ifstream file_in(csv_file_name);
    if (!file_in)
        throw std::runtime_error("Failed to open file for loading.");

    items_.clear();
    while (file_in)
    {
        std::shared_ptr<Abstraction> temp = std::make_shared<Boat>(0, nullptr, std::chrono::year_month_day{}, false);
        temp->recv_from(file_in);
        if (file_in)
            items_.push_back(temp);
    }
}
