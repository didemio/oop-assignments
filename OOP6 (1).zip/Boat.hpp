﻿#ifndef BOAT_HPP
#define BOAT_HPP

#include "Abstraction.hpp"
#include "BoatSpec.hpp"

class Boat : public Abstraction
{
public:
    Boat(int id, std::shared_ptr<BoatSpec> spec, std::chrono::year_month_day date, bool sold);

    std::shared_ptr<AbstractionSpec> get_spec() const override;
    int get_id() const override;
    bool get_sold() const override;
    std::chrono::year_month_day get_date_purchased() const override;
    bool matches(const AbstractionSpec& spec) const override;

    void send_to(std::ostream& os) const override;
    void recv_from(std::istream& is) override;

private:
    int _id{};
    std::chrono::year_month_day _date_purchased{};
    bool _sold{};
    std::shared_ptr<BoatSpec> _spec;
};

#endif
