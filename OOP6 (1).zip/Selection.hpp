﻿#ifndef SELECTION_HPP
#define SELECTION_HPP

#include "Abstraction.hpp"
#include <vector>
#include <memory>
#include <chrono>
#include <stdexcept>
#include <fstream>
#include <string>

class Selection
{
public:
    Selection() = default;
    Selection(const std::string& csv_file_name) { load(csv_file_name); }

    void save(const std::string& csv_file_name) const;
    void load(const std::string& csv_file_name);

    const Abstraction& get(size_t i) const
    {
        if (i < items_.size())
            return *items_[i];
        throw std::out_of_range("Invalid index value.");
    }

    const Abstraction& operator[](size_t i) const { return get(i); }

    void add(std::shared_ptr<Abstraction> abstraction)
    {
        items_.push_back(abstraction);
    }

    const Abstraction& search(const AbstractionSpec& spec);
    const Abstraction& search(int id);

private:
    std::vector<std::shared_ptr<Abstraction>> items_;
};

#endif
