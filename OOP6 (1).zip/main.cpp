﻿#include <iostream>
#include <memory>
#include <chrono>
#include <cassert>
#include <iomanip>
#include "Boat.hpp"
#include "BoatSpec.hpp"
#include "Selection.hpp"

void show(const Abstraction& item)
{
    std::cout << item << std::endl;
}

int main()
{
    Selection sel;

    auto boat_spec_1 = std::make_shared<BoatSpec>("Sailing Boat", 2022, 25000.50);
    auto boat_1 = std::make_shared<Boat>(1, boat_spec_1, std::chrono::year_month_day{ std::chrono::year(2022), std::chrono::month(5), std::chrono::day(15) }, false);
    sel.add(boat_1);

    auto boat_spec_2 = std::make_shared<BoatSpec>("Motor Boat", 2021, 32000.75);
    auto boat_2 = std::make_shared<Boat>(2, boat_spec_2, std::chrono::year_month_day{ std::chrono::year(2021), std::chrono::month(3), std::chrono::day(10) }, true);
    sel.add(boat_2);

    auto shared_spec = std::make_shared<BoatSpec>("Luxury Yacht", 2025, 75000.00);
    auto boat_3 = std::make_shared<Boat>(3, shared_spec, std::chrono::year_month_day{ std::chrono::year(2025), std::chrono::month(7), std::chrono::day(1) }, false);
    auto boat_4 = std::make_shared<Boat>(4, shared_spec, std::chrono::year_month_day{ std::chrono::year(2025), std::chrono::month(6), std::chrono::day(20) }, true);
    sel.add(boat_3);
    sel.add(boat_4);

    show(sel.search(*boat_spec_1));
    show(sel.search(*boat_spec_2));
    show(sel.search(*shared_spec));

    try {
        show(sel[100]); // trigger out_of_range
    }
    catch (const std::out_of_range& e) {
        std::cerr << "Caught exception: " << e.what() << std::endl;
        assert(true);
    }

    sel.save("boats.csv");
    Selection another_sel("boats.csv");
    show(another_sel[0]);
    show(another_sel[1]);

    return 0;
}
