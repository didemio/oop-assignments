﻿#include "Boat.hpp"

Boat::Boat(int id, std::shared_ptr<BoatSpec> spec, std::chrono::year_month_day date, bool sold)
    : id_(id), spec_(spec), date_purchased_(date), sold_(sold)
{
}

std::shared_ptr<AbstractionSpec> Boat::get_spec() const
{
    return spec_;
}

int Boat::get_id() const
{
    return id_;
}

bool Boat::get_sold() const
{
    return sold_;
}

std::chrono::year_month_day Boat::get_date_purchased() const
{
    return date_purchased_;
}

bool Boat::matches(const AbstractionSpec& spec) const
{
    const BoatSpec& boat_spec = dynamic_cast<const BoatSpec&>(spec);
    return spec_->matches(boat_spec);
}
