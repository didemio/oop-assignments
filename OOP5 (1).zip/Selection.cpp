﻿#include "Selection.hpp"

void Selection::add(int id, std::shared_ptr<Abstraction> abstraction)
{
    items_.push_back(abstraction);  
}

Abstraction Selection::search(const AbstractionSpec& spec)
{
    for (const auto& item : items_)
    {
        if (item->matches(spec))  
        {
            return *item;
        }
    }
    return Abstraction(0, nullptr);  
}

Abstraction Selection::search(int id)
{
    for (const auto& item : items_)
    {
        if (item->get_id() == id)  
        {
            return *item;
        }
    }
    return Abstraction(0, nullptr);  
}
