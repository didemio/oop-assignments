﻿#ifndef SELECTION_HPP
#define SELECTION_HPP

#include "Abstraction.hpp"
#include <vector>
#include <memory>
#include <chrono>

class Selection
{
public:
    void add(int id, std::shared_ptr<Abstraction> abstraction);  
    Abstraction search(const AbstractionSpec& spec); 
    Abstraction search(int id);  

private:
    std::vector<std::shared_ptr<Abstraction>> items_;  
};

#endif /
