﻿#ifndef BOAT_HPP
#define BOAT_HPP

#include "Abstraction.hpp"
#include "BoatSpec.hpp"
#include <memory>

class Boat : public Abstraction
{
public:
    Boat(int id, std::shared_ptr<BoatSpec> spec, std::chrono::year_month_day date, bool sold);

    std::shared_ptr<AbstractionSpec> get_spec() const override;  
    int get_id() const override;   
    bool get_sold() const override; 

    std::chrono::year_month_day get_date_purchased() const override; 
    bool matches(const AbstractionSpec& spec) const override;  

private:
    int id_;
    std::shared_ptr<BoatSpec> spec_;
    std::chrono::year_month_day date_purchased_;
    bool sold_;
};

#endif /
