#include "BoatSpec.hpp"

BoatSpec::BoatSpec(std::string modelYear, double price)
    : model_year(modelYear), price(price)
{
}

std::string BoatSpec::get_model() const
{
    return model_year;
}

int BoatSpec::get_model_year() const
{
    return std::stoi(model_year);  
}

double BoatSpec::get_price() const
{
    return price;
}

std::string BoatSpec::get_type_str() const
{
    return "Boat";  
}

bool BoatSpec::matches(const AbstractionSpec& spec) const
{
    const BoatSpec& boat_spec = dynamic_cast<const BoatSpec&>(spec);
    return model_year == boat_spec.model_year && price == boat_spec.price;
}
