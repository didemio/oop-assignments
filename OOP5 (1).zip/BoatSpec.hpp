#ifndef BOATSPEC_HPP
#define BOATSPEC_HPP

#include "AbstractionSpec.hpp"  
#include <memory>

class BoatSpec : public AbstractionSpec
{
private:
    std::string model_year;
    double price;

public:
    BoatSpec(std::string modelYear, double price);
    std::string get_model() const override; 
    int get_model_year() const override;    
    double get_price() const override;      
    std::string get_type_str() const override;
    bool matches(const AbstractionSpec& spec) const override;  
};

#endif 
