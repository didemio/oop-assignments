#include "Abstraction.hpp"

Abstraction::Abstraction(std::shared_ptr<const AbstractionSpec> abstractionSpec)
    : spec(abstractionSpec)
{
}

std::shared_ptr<AbstractionSpec> Abstraction::get_spec() const
{
    return spec;
}
