#ifndef ABSTRACTION_HPP
#define ABSTRACTION_HPP

#include <memory>
#include <chrono>
#include <string>
#include "AbstractionSpec.hpp"  

class Abstraction {
public:
    virtual ~Abstraction() = default;

    virtual std::shared_ptr<AbstractionSpec> get_spec() const = 0;
    virtual int get_id() const = 0;
    virtual bool get_sold() const = 0;
    virtual std::chrono::year_month_day get_date_purchased() const = 0;
    virtual bool matches(const AbstractionSpec& spec) const = 0;
};

#endif /
