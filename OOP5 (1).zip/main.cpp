﻿#include <iostream>
#include <memory>
#include <chrono>
#include <cassert>
#include <iomanip>
#include "Boat.hpp"
#include "BoatSpec.hpp"
#include "Selection.hpp"


void show(const Boat& item)
{
    auto is_p = item.get_spec();  

    if (!is_p)
        is_p.reset(new BoatSpec("Default Model", 2022, 500.00));  

    std::cout << item.get_id() << " "
        << "'" << is_p->get_model() << "' "
        << is_p->get_model_year() << " "
        << "'" << is_p->get_type_str() << "' "
        << std::fixed << std::setprecision(2) << is_p->get_price()
        << " " << item.get_date_purchased()
        << " " << std::boolalpha << item.get_sold()
        << std::endl;
}

int main()
{
    Selection sel;

 
    auto boat_spec_1 = std::make_shared<BoatSpec>("Sailing Boat", 2022, 25000.50);
    auto boat_1 = std::make_shared<Boat>(1, boat_spec_1, std::chrono::year_month_day{ 2022y, 5, 15 }, false);
    sel.add(1, boat_1);

 
    auto boat_spec_2 = std::make_shared<BoatSpec>("Motor Boat", 2021, 32000.75);
    auto boat_2 = std::make_shared<Boat>(2, boat_spec_2, std::chrono::year_month_day{ 2021y, 3, 10 }, true);
    sel.add(2, boat_2);

  
    auto shared_spec = std::make_shared<BoatSpec>("Luxury Yacht", 2025, 75000.00);
    auto boat_3 = std::make_shared<Boat>(3, shared_spec, std::chrono::year_month_day{ 2025y, 7, 1 }, false);
    auto boat_4 = std::make_shared<Boat>(4, shared_spec, std::chrono::year_month_day{ 2025y, 6, 20 }, true);
    sel.add(3, boat_3);
    sel.add(4, boat_4);

    
    show(sel.search(BoatSpec("Sailing Boat", 2022, 25000.50)));
    show(sel.search(BoatSpec("Motor Boat", 2021, 32000.75)));
    show(sel.search(BoatSpec("Luxury Yacht", 2025, 75000.00)));

  
    show(sel.search(BoatSpec("Non Existent Boat", 0, 0.00)));

    return 0;
}
