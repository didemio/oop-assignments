﻿#include "Selection.hpp"
#include <iostream>
#include <cassert>

const Boat& max_length(const Selection& sel) {
    assert(sel.get_count() > 0 && "Selection is empty!");

    const Boat* maxBoat = &sel.get(0);
    for (int i = 1; i < sel.get_count(); ++i) {
        if (sel.get(i).get_length() > maxBoat->get_length()) {
            maxBoat = &sel.get(i);
        }
    }
    return *maxBoat;
}

double avg_length(const Selection& sel) {
    assert(sel.get_count() > 0 && "Selection is empty!");

    double totalLength = 0.0;
    for (int i = 0; i < sel.get_count(); ++i) {
        totalLength += sel.get(i).get_length();
    }
    return totalLength / sel.get_count();
}

int main() {
    Selection sel;

    Boat yacht1(Boat::BoatType::YACHT, 15.0, 8, 2020);
    Boat yacht2(Boat::BoatType::YACHT, 20.0, 10, 2022);

    sel.add(yacht1);
    sel.add(yacht2);

    assert(max_length(sel).get_length() == 20.0 && "Max length function failed!");

    assert(avg_length(sel) == 17.5 && "Average length function failed!");

    std::cout << "All assertions passed successfully!\n";

    return 0;
}
