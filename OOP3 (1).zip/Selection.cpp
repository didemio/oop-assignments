﻿#include "Selection.hpp"

void Selection::add(const Boat& boat) {
    assert(search(boat) == nullptr && "Boat already exists in the selection!");

    boats.push_back(boat);
}

const Boat* Selection::search(const Boat& query) const {
    for (const auto& boat : boats) {
        if (boat.get_type() == query.get_type() &&
            boat.get_length() == query.get_length() &&
            boat.get_capacity() == query.get_capacity() &&
            boat.get_manufacture_year() == query.get_manufacture_year()) {
            return &boat;
        }
    }
    return nullptr;
}
