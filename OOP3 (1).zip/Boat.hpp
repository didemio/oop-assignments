﻿#pragma once
#include <string>

class Boat {
public:
    enum class BoatType { ANY, YACHT };
    static constexpr const char* BoatType_str[] = { "Any", "Yacht" };

    Boat(BoatType type = BoatType::ANY, double length = 0.0, int capacity = 0, int manufactureYear = 0);

    BoatType get_type() const { return _type; }
    const char* get_type_str() const { return BoatType_str[static_cast<std::size_t>(_type)]; }
    double get_length() const { return _length; }
    int get_capacity() const { return _capacity; }
    int get_manufacture_year() const { return _manufactureYear; }

private:
    BoatType _type;
    double _length;
    int _capacity;
    int _manufactureYear;
};
