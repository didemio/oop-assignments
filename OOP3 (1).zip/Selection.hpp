﻿#pragma once
#include "Boat.hpp"
#include <vector>
#include <cassert>

class Selection {
public:
    void add(const Boat& boat);
    const Boat* search(const Boat& query) const;

    int get_count() const { return boats.size(); }
    const Boat& get(int index) const { return boats.at(index); }

private:
    std::vector<Boat> boats;
};
