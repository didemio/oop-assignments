#pragma once
#include "AbstractionSpec.hpp"
#include <chrono>

class Abstraction {
public:
    // Default constructor
    Abstraction() = default;

    // Parametrized constructor
    Abstraction(int id, const AbstractionSpec& spec, std::chrono::year_month_day date_purchased, bool sold)
        : _id{ id }
        , _spec{ spec }
        , _date_purchased{ date_purchased }
        , _sold{ sold }
    {
    }

    int get_id() const { return _id; }
    std::chrono::year_month_day get_date_purchased() const { return _date_purchased; }
    bool get_sold() const { return _sold; }
    const AbstractionSpec& get_spec() const { return _spec; }

private:
    int _id{ 0 };  // Default initialization for id
    AbstractionSpec _spec{};
    std::chrono::year_month_day _date_purchased{};
    bool _sold{ false };  // Default initialization for sold
};
