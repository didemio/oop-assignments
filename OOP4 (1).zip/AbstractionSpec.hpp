#pragma once
#include <string>
#include <string_view>

class AbstractionSpec {
public:
    enum class Type { ANY, YACHT, SAILBOAT, FISHING_BOAT };
    static constexpr std::string_view Type_str[]{ "Any", "Yacht", "Sailboat", "Fishing Boat" };

    AbstractionSpec() = default;
    AbstractionSpec(std::string model, unsigned short model_year, Type type, double length)
        : _model{ model }
        , _model_year{ model_year }
        , _type{ type }
        , _length{ length }
    {
    }

    std::string get_model() const { return _model; }
    unsigned short get_model_year() const { return _model_year; }
    Type get_type() const { return _type; }
    std::string_view get_type_str() const { return Type_str[static_cast<std::size_t>(_type)]; }
    double get_length() const { return _length; }

private:
    std::string _model{};
    unsigned short _model_year{ 0 };
    Type _type{ Type::ANY };
    double _length{ 0.0 };
};
