﻿#include "Selection.hpp"
#include "Boat.hpp"
#include <iostream>
#include <chrono>
#include <cassert>

void show(const Boat& item)
{
    std::cout << item.get_id()
        << " '" << item.get_model() << "' "
        << " " << item.get_year() << " "
        << " " << item.get_price()
        << " " << item.get_date_purchased()
        << " " << std::boolalpha << item.is_sold()
        << std::endl;
}

int main()
{
    Selection sel;

    // Add some boats to the selection
    sel.add(1, "Boat A", 2020, 10000.0, std::chrono::year_month_day{ std::chrono::year{2021}, std::chrono::month{10}, std::chrono::day{1} }, true);
    sel.add(2, "Boat B", 2021, 15000.0, std::chrono::year_month_day{ std::chrono::year{2022}, std::chrono::month{6}, std::chrono::day{15} }, false);
    sel.add(3, "Boat C", 2019, 12000.0, std::chrono::year_month_day{ std::chrono::year{2020}, std::chrono::month{8}, std::chrono::day{12} }, true);
    sel.add(4, "Boat D", 2021, 16000.0, std::chrono::year_month_day{ std::chrono::year{2022}, std::chrono::month{5}, std::chrono::day{10} }, false);

    // Test search by Boat object
    Boat qry1(2, "Boat B", 2021, 15000.0, std::chrono::year_month_day{}, false);
    Boat found = sel.search(qry1);
    assert(found.get_id() == 2);  // Check if the boat with ID 2 is found
    show(found);

    // Test search by specification
    Boat found_by_spec = sel.search("Boat C", 2019, 12000.0);
    show(found_by_spec);

    return 0;
}
