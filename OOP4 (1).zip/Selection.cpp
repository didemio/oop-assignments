﻿#include "Selection.hpp"
#include "Boat.hpp"
#include <iostream>

void Selection::add(int id, const std::string& model, int year, double price, std::chrono::year_month_day date_purchased, bool sold)
{
    if (_count < MAX_SIZE)
    {
        _items[_count++] = Boat(id, model, year, price, date_purchased, sold);
        std::cout << "Adding Boat with ID: " << id << std::endl;
    }
}

Boat Selection::search(const Boat& query) const
{
    for (size_t i = 0; i < _count; ++i)
    {
        if (query.get_id() != 0 && query.get_id() != _items[i].get_id()) {
            continue;
        }

        if (!query.get_model().empty() && query.get_model() != _items[i].get_model()) {
            continue;
        }

        if (query.get_year() != 0 && query.get_year() != _items[i].get_year()) {
            continue;
        }

        if (query.get_price() != 0.0 && query.get_price() != _items[i].get_price()) {
            continue;
        }

        if (query.is_sold() != _items[i].is_sold()) {
            continue;
        }

        return _items[i];  // Found the matching boat
    }

    return Boat{};  // Return a default boat if no match is found
}

Boat Selection::search(const std::string& model, int year, double price) const
{
    for (size_t i = 0; i < _count; ++i)
    {
        if (!model.empty() && model != _items[i].get_model()) {
            continue;
        }
        if (year != 0 && year != _items[i].get_year()) {
            continue;
        }
        if (price != 0.0 && price != _items[i].get_price()) {
            continue;
        }

        return _items[i];  // Return the matching boat
    }

    return Boat{};  // Return a default boat if no match is found
}
