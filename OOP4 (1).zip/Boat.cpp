﻿#include "Boat.hpp"

// Constructor definition
Boat::Boat(int id, const std::string& model, int year, double price, std::chrono::year_month_day date_purchased, bool sold)
    : _id{ id }, _model{ model }, _year{ year }, _price{ price }, _date_purchased{ date_purchased }, _sold{ sold }
{
}

// Getter function definitions
int Boat::get_id() const {
    return _id;
}

const std::string& Boat::get_model() const {
    return _model;
}

int Boat::get_year() const {
    return _year;
}

double Boat::get_price() const {
    return _price;
}

bool Boat::is_sold() const {
    return _sold;
}

std::chrono::year_month_day Boat::get_date_purchased() const {
    return _date_purchased;
}
