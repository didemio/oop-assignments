﻿#ifndef SELECTION_HPP
#define SELECTION_HPP

#include "Boat.hpp"
#include <array>
#include <chrono>

class Selection {
public:
    static const size_t MAX_SIZE = 100;
    void add(int id, const std::string& model, int year, double price, std::chrono::year_month_day date_purchased, bool sold);
    Boat search(const Boat& query) const;
    Boat search(const std::string& model, int year, double price) const;

private:
    std::array<Boat, MAX_SIZE> _items;
    size_t _count{ 0 };
};

#endif // SELECTION_HPP
