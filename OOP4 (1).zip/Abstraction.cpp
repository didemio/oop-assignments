#include "Abstraction.hpp"

// Nothing else needed here (for now)
