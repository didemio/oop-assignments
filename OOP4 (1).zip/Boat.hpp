﻿#ifndef BOAT_HPP
#define BOAT_HPP

#include <string>
#include <chrono>

class Boat {
public:
    Boat() = default;  // Default constructor
    Boat(int id, const std::string& model, int year, double price, std::chrono::year_month_day date_purchased, bool sold);

    int get_id() const;
    const std::string& get_model() const;
    int get_year() const;
    double get_price() const;
    bool is_sold() const;
    std::chrono::year_month_day get_date_purchased() const;

private:
    int _id{ 0 };
    std::string _model;
    int _year{ 0 };
    double _price{ 0.0 };
    std::chrono::year_month_day _date_purchased;
    bool _sold{ false };
};

#endif // BOAT_HPP
