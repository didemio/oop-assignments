#pragma once

#include <string>
#include <chrono>
#include <iostream>

using std::chrono::year_month_day;
using namespace std::chrono;

constexpr auto csv_delimiter{ ';' };

std::string to_string(const year_month_day& ymd);
year_month_day from_string(const std::string& str);

#ifdef _MSC_VER
#define strcasecmp _stricmp
#else
#include <strings.h>
#endif
