#include "Item.hpp"

bool Item::matches(const Item& other) const {
    if (this == &other)
        return true;
    return 0 == other._id || this->_id == other._id;
}

void Item::send_to(std::ostream& os) const {
    os << _id;
}

void Item::recv_from(std::istream& is) {
    if (is) {
        is >> _id;
        is.ignore();
    }
}

std::ostream& operator<<(std::ostream& os, const Item& item) {
    if (os) item.send_to(os);
    return os;
}

std::istream& operator>>(std::istream& is, Item& item) {
    if (is) item.recv_from(is);
    return is;
}
