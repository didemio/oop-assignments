#ifndef ABSTRACTIONSPEC_HPP
#define ABSTRACTIONSPEC_HPP

#include <memory>
#include <string>

class AbstractionSpec
{
public:
    virtual ~AbstractionSpec() = default;

    virtual bool matches(const AbstractionSpec& spec) const = 0;

    virtual std::string get_model() const = 0;
    virtual int get_model_year() const = 0;
    virtual double get_price() const = 0;
    virtual std::string get_type_str() const = 0;
};

#endif 
