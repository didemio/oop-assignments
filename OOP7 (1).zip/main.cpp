﻿#include <iostream>
#include <memory>
#include <chrono>
#include <cassert>
#include <vector>
#include <algorithm>

#include "Boat.hpp"
#include "BoatSpec.hpp"
#include "Bike.hpp"
#include "BikeSpec.hpp"
#include "Selection.hpp"

template <typename T>
void show(const T& item) {
    std::cout << item << "\n";
}

template <typename T>
void show(const std::vector<std::shared_ptr<T>>& items) {
    std::for_each(items.begin(), items.end(), [](auto item) {
        show(*item);
        });
}

int main() {
    Selection sel;

    // Boats
    auto boat_spec1 = std::make_shared<BoatSpec>("SailMaster", 2020, 15000.0);
    auto boat1 = std::make_shared<Boat>(1, boat_spec1, std::chrono::year_month_day{ std::chrono::year{2020}, std::chrono::month{5}, std::chrono::day{20} }, false);
    sel.add(boat1);

    auto boat_spec2 = std::make_shared<BoatSpec>("WaveRunner", 2021, 20000.0);
    auto boat2 = std::make_shared<Boat>(2, boat_spec2, std::chrono::year_month_day{ std::chrono::year{2021}, std::chrono::month{6}, std::chrono::day{15} }, true);
    sel.add(boat2);

    std::cout << "All boats in selection:\n";
    show(sel.search(*boat1));
    show(sel.search(*boat2));

    // Bikes
    auto bike_spec1 = std::make_shared<BikeSpec>("MountainX", 2022, 1200.0);
    auto bike1 = std::make_shared<Bike>(3, bike_spec1, std::chrono::year_month_day{ std::chrono::year{2022}, std::chrono::month{9}, std::chrono::day{1} }, false);
    sel.add(bike1);

    auto bike_spec2 = std::make_shared<BikeSpec>("RoadMaster", 2023, 1800.0);
    auto bike2 = std::make_shared<Bike>(4, bike_spec2, std::chrono::year_month_day{ std::chrono::year{2023}, std::chrono::month{3}, std::chrono::day{18} }, true);
    sel.add(bike2);

    std::cout << "\nAll bikes:\n";
    show(sel.search(*bike1));
    show(sel.search(*bike2));

    // Exception test
    try {
        auto invalid = sel[100];
        show(*invalid);
    }
    catch (const std::out_of_range& e) {
        std::cerr << "Caught exception: " << e.what() << std::endl;
        assert(true);
    }

    sel.save("items.csv");

    Selection another_sel("items.csv");
    std::cout << "\nDone.\n";
    return 0;
}
