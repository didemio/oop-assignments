#include "BoatSpec.hpp"
#include "utilities.hpp"

BoatSpec::BoatSpec(std::string model, int year, double price)
    : _model(std::move(model)), _model_year(year), _price(price) {
}

std::string BoatSpec::get_model() const { return _model; }
int BoatSpec::get_model_year() const { return _model_year; }
double BoatSpec::get_price() const { return _price; }
std::string BoatSpec::get_type_str() const { return "Boat"; }

bool BoatSpec::matches(const AbstractionSpec& spec) const
{
    const auto* other = dynamic_cast<const BoatSpec*>(&spec);
    return other && _model == other->_model && _model_year == other->_model_year && _price == other->_price;
}

void BoatSpec::send_to(std::ostream& os) const
{
    os << _model << csv_delimiter << _model_year << csv_delimiter << _price;
}

void BoatSpec::recv_from(std::istream& is)
{
    std::getline(is, _model, csv_delimiter);
    is >> _model_year;
    is.ignore();
    is >> _price;
}

std::ostream& operator<<(std::ostream& os, const BoatSpec& spec)
{
    spec.send_to(os);
    return os;
}

std::istream& operator>>(std::istream& is, BoatSpec& spec)
{
    spec.recv_from(is);
    return is;
}
