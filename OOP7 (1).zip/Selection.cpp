﻿#include "Selection.hpp"
#include <fstream>
#include <algorithm>

void Selection::add(std::shared_ptr<Item> new_item) {
    if (!new_item) return;

    auto found = std::find_if(_items.begin(), _items.end(),
        [&new_item](const std::shared_ptr<Item>& item) {
            return item && item->get_id() == new_item->get_id();
        });

    if (found != _items.end()) return;

    _items.push_back(new_item);
}

std::vector<std::shared_ptr<Item>> Selection::search(const Item& query) const {
    std::vector<std::shared_ptr<Item>> result;

    for (const auto& item : _items) {
        if (item && item->matches(query))
            result.push_back(item);
    }

    return result;
}

void Selection::save(const std::string& file_name) const {
    std::ofstream out(file_name);
    if (!out) return;

    for (const auto& item : _items)
        if (item)
            out << *item << "\n";
}

void Selection::load(const std::string& file_name) {
    std::ifstream in(file_name);
    if (!in) return;

    _items.clear();
    
}
