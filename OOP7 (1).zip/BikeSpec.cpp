#include "BikeSpec.hpp"
#include "utilities.hpp"

BikeSpec::BikeSpec(std::string model, int year, double price)
    : _model(std::move(model)), _model_year(year), _price(price) {
}

std::string BikeSpec::get_model() const { return _model; }
int BikeSpec::get_model_year() const { return _model_year; }
double BikeSpec::get_price() const { return _price; }
std::string BikeSpec::get_type_str() const { return "Bike"; }

bool BikeSpec::matches(const AbstractionSpec& spec) const {
    const auto* b = dynamic_cast<const BikeSpec*>(&spec);
    return b && _model == b->_model && _model_year == b->_model_year && _price == b->_price;
}

void BikeSpec::send_to(std::ostream& os) const {
    os << _model << csv_delimiter << _model_year << csv_delimiter << _price;
}

void BikeSpec::recv_from(std::istream& is) {
    std::getline(is, _model, csv_delimiter);
    is >> _model_year;
    is.ignore();
    is >> _price;
}
