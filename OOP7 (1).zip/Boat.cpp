﻿#include "Boat.hpp"
#include "utilities.hpp"

bool Boat::matches(const Item& other) const {
    bool result = Item::matches(other);

    const Boat* other_boat = dynamic_cast<const Boat*>(&other);
    if (!other_boat)
        return false;

    if (result && _spec && other_boat->_spec)
        result = _spec->matches(*other_boat->_spec);

    if (result)
        result = _date_purchased == other_boat->_date_purchased;

    if (result)
        result = _sold == other_boat->_sold;

    return result;
}

void Boat::send_to(std::ostream& os) const {
    Item::send_to(os);
    os << csv_delimiter
        << to_string(_date_purchased) << csv_delimiter
        << _sold << csv_delimiter;

    if (_spec)
        _spec->send_to(os);
    else
        BoatSpec().send_to(os);
}

void Boat::recv_from(std::istream& is) {
    Item::recv_from(is);

    std::string date_str;
    std::getline(is, date_str, csv_delimiter);
    _date_purchased = from_string(date_str);

    is >> _sold;
    is.ignore();

    auto temp_spec = std::make_shared<BoatSpec>();
    temp_spec->recv_from(is);
    _spec = temp_spec;
}
