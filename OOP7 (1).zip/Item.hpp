#pragma once
#include <iostream>

class Item {
public:
    Item() = default;
    virtual ~Item() = default;

    Item(int id) : _id(id) {}

    int get_id() const { return _id; }

    virtual bool matches(const Item& other) const = 0;
    virtual void send_to(std::ostream& os) const = 0;
    virtual void recv_from(std::istream& is) = 0;

private:
    int _id;
};

std::ostream& operator<<(std::ostream& os, const Item& item);
std::istream& operator>>(std::istream& is, Item& item);

