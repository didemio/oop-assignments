#include "Bike.hpp"
#include "utilities.hpp"

Bike::Bike(int id, std::shared_ptr<BikeSpec> spec, std::chrono::year_month_day date, bool sold)
    : Item(id), _spec(spec), _date_purchased(date), _sold(sold) {
}

std::shared_ptr<BikeSpec> Bike::get_spec() const { return _spec; }
std::chrono::year_month_day Bike::get_date_purchased() const { return _date_purchased; }
bool Bike::get_sold() const { return _sold; }

bool Bike::matches(const Item& other) const {
    bool result = Item::matches(other);

    const Bike* other_bike = dynamic_cast<const Bike*>(&other);
    if (!other_bike)
        return false;

    if (result && _spec && other_bike->_spec)
        result = _spec->matches(*other_bike->_spec);

    if (result)
        result = _date_purchased == other_bike->_date_purchased;

    if (result)
        result = _sold == other_bike->_sold;

    return result;
}

void Bike::send_to(std::ostream& os) const {
    Item::send_to(os);
    os << csv_delimiter
        << to_string(_date_purchased) << csv_delimiter
        << _sold << csv_delimiter;

    if (_spec)
        _spec->send_to(os);
    else
        BikeSpec().send_to(os);
}

void Bike::recv_from(std::istream& is) {
    Item::recv_from(is);

    std::string date_str;
    std::getline(is, date_str, csv_delimiter);
    _date_purchased = from_string(date_str);

    is >> _sold;
    is.ignore();

    auto temp_spec = std::make_shared<BikeSpec>();
    temp_spec->recv_from(is);
    _spec = temp_spec;
}
