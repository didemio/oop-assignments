#define _CRT_SECURE_NO_WARNINGS  // Suppress C4996 warning

#include "utilities.hpp"
#include <iomanip>
#include <sstream>

std::string to_string(const std::chrono::year_month_day& ymd)
{
    std::ostringstream os;
    os << static_cast<int>(ymd.year()) << '-'
        << std::setw(2) << std::setfill('0') << static_cast<unsigned>(ymd.month()) << '-'
        << std::setw(2) << std::setfill('0') << static_cast<unsigned>(ymd.day());
    return os.str();
}

std::chrono::year_month_day from_string(const std::string& str)
{
    int y, m, d;
    char sep1, sep2;
    std::istringstream is(str);
    is >> y >> sep1 >> m >> sep2 >> d;

    return std::chrono::year_month_day{
        std::chrono::year{y},
        std::chrono::month{static_cast<unsigned>(m)},
        std::chrono::day{static_cast<unsigned>(d)}
    };
}
