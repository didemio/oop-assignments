#ifndef BOATSPEC_HPP
#define BOATSPEC_HPP

#include "AbstractionSpec.hpp"
#include <memory>
#include <string>
#include <iostream>

class BoatSpec : public AbstractionSpec
{
public:
    BoatSpec(std::string model = "", int year = 0, double price = 0.0);

    std::string get_model() const override;
    int get_model_year() const override;
    double get_price() const override;
    std::string get_type_str() const override;
    bool matches(const AbstractionSpec& spec) const override;

    void send_to(std::ostream& os) const;
    void recv_from(std::istream& is);

private:
    std::string _model;
    int _model_year;
    double _price;
};

#endif
