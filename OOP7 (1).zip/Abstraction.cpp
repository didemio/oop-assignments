#include "Abstraction.hpp"
// No extra logic here since everything is abstract and interface-based
