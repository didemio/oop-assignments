#ifndef ABSTRACTION_HPP
#define ABSTRACTION_HPP

#include <memory>
#include <chrono>
#include <string>
#include <iostream>
#include "AbstractionSpec.hpp"

class Abstraction
{
public:
    virtual ~Abstraction() = default;

    virtual std::shared_ptr<AbstractionSpec> get_spec() const = 0;
    virtual int get_id() const = 0;
    virtual bool get_sold() const = 0;
    virtual std::chrono::year_month_day get_date_purchased() const = 0;
    virtual bool matches(const AbstractionSpec& spec) const = 0;

    virtual void send_to(std::ostream& os) const = 0;
    virtual void recv_from(std::istream& is) = 0;
};

inline std::ostream& operator<<(std::ostream& os, const Abstraction& item)
{
    item.send_to(os);
    return os;
}

inline std::istream& operator>>(std::istream& is, std::shared_ptr<Abstraction>& item)
{
    item->recv_from(is);
    return is;
}

#endif
