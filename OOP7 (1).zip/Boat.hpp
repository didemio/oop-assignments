﻿#pragma once
#include "Item.hpp"
#include "BoatSpec.hpp"  
#include <memory>
#include <string>
#include <chrono>

class Boat : public Item {
public:
    Boat() = default;
    Boat(int id, std::shared_ptr<BoatSpec> spec, std::chrono::year_month_day date, bool sold)
        : Item(id), _spec(spec), _date_purchased(date), _sold(sold) {
    }

    std::shared_ptr<BoatSpec> get_spec() const { return _spec; }
    std::chrono::year_month_day get_date_purchased() const { return _date_purchased; }
    bool get_sold() const { return _sold; }

    bool matches(const Item& other) const override;
    void send_to(std::ostream& os) const override;
    void recv_from(std::istream& is) override;

private:
    std::shared_ptr<BoatSpec> _spec;
    std::chrono::year_month_day _date_purchased;
    bool _sold;
};
