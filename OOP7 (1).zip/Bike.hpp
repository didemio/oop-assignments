#pragma once
#include "Item.hpp"
#include "BikeSpec.hpp"
#include <memory>
#include <chrono>

class Bike : public Item {
public:
    Bike() = default;
    Bike(int id, std::shared_ptr<BikeSpec> spec, std::chrono::year_month_day date, bool sold);

    std::shared_ptr<BikeSpec> get_spec() const;
    std::chrono::year_month_day get_date_purchased() const;
    bool get_sold() const;

    bool matches(const Item& other) const override;
    void send_to(std::ostream& os) const override;
    void recv_from(std::istream& is) override;

private:
    std::shared_ptr<BikeSpec> _spec;
    std::chrono::year_month_day _date_purchased;
    bool _sold;
};
