﻿#pragma once

#include "Item.hpp"
#include <string>
#include <memory>
#include <vector>
#include <stdexcept>

class Selection {
public:
    Selection() = default;

    Selection(const std::string& csv_file_name) {
        load(csv_file_name);
    }

    size_t get_count() const { return _items.size(); }

    std::shared_ptr<Item> get(size_t i) const {
        if (i < get_count())
            return _items[i];
        throw std::out_of_range("Invalid index value.");
    }

    std::shared_ptr<Item> operator[](size_t i) const { return get(i); }

    void add(std::shared_ptr<Item> new_item);

    std::vector<std::shared_ptr<Item>> search(const Item& query) const;

    void save(const std::string& file_name) const;
    void load(const std::string& file_name);

private:
    std::vector<std::shared_ptr<Item>> _items;
};
