#include "Selection.hpp"

void Selection::add(std::string type, double length, int capacity, int manufactureYear) {
    if (_count < Selection::MAX_COUNT) {
        Boat new_item;
        new_item.init(type, length, capacity, manufactureYear);
        _items[_count] = new_item;
        _count++;
    }
}

Boat Selection::search(Boat query) {
    for (size_t i{ 0 }; i < _count; i++) {
        if (!query.get_type().empty() && query.get_type() != _items[i].get_type())
            continue;

        constexpr double epsil{ 0.005 };
        if (0.0 != query.get_length() && epsil < std::abs(query.get_length() - _items[i].get_length()))
            continue;

        if (0 != query.get_capacity() && query.get_capacity() != _items[i].get_capacity())
            continue;

        if (0 != query.get_manufacture_year() && query.get_manufacture_year() != _items[i].get_manufacture_year())
            continue;

        return _items[i];
    }

    return Boat{};
}
