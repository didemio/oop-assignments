#pragma once
#include <string>

class Boat {
public:
    Boat(); // Default constructor
    void init(std::string type, double length, int capacity, int manufactureYear);
    std::string get_type() { return _type; }
    double get_length() { return _length; }
    int get_capacity() { return _capacity; }
    int get_manufacture_year() { return _manufactureYear; }

private:
    std::string _type;
    double _length;
    int _capacity;
    int _manufactureYear;
};


