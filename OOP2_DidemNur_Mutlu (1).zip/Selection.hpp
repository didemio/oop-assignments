#pragma once
#include "Boat.hpp"

class Selection {
public:
    static const size_t MAX_COUNT{ 5 };

    void init() { _count = 0; }
    size_t get_count() { return _count; }
    Boat get(size_t i) { return (i < _count) ? _items[i] : Boat{}; }
    void add(std::string type, double length, int capacity, int manufactureYear);
    Boat search(Boat query);

private:
    Boat _items[Selection::MAX_COUNT];
    size_t _count;
};

