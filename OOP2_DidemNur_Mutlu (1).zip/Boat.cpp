#include "Boat.hpp"

Boat::Boat() {
    _type = "Unknown";
    _length = 0.0;
    _capacity = 0;
    _manufactureYear = 0;
}

void Boat::init(std::string type, double length, int capacity, int manufactureYear) {
    _type = type;
    _length = length;
    _capacity = capacity;
    _manufactureYear = manufactureYear;
}
