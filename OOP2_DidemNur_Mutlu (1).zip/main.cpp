#include "Boat.hpp"
#include "Selection.hpp"
#include <iostream>
#include <cassert>

void show(Boat item) {
    std::cout << item.get_type() << " "
        << item.get_length() << "m "
        << item.get_capacity() << " people "
        << item.get_manufacture_year()
        << std::endl;
}

int main() {
    Selection sel;
    sel.init();

    // Add different boats to selection
    sel.add("Sailboat", 12.5, 6, 2015);
    sel.add("Yacht", 15.0, 8, 2020);
    sel.add("Motorboat", 8.2, 4, 2018);

    // Ensure boats were added correctly
    assert(sel.get_count() == 3);

    Boat qry, result;

    // Search for a boat with a specific length
    qry.init("", 15.0, 0, 0);
    result = sel.search(qry);
    show(result);
    assert(result.get_type() == "Yacht");

    // Search for a boat with a specific type
    qry.init("Sailboat", 0.0, 0, 0);
    result = sel.search(qry);
    show(result);
    assert(result.get_length() == 12.5);

    // Search for a boat with a specific manufacture year
    qry.init("", 0.0, 0, 2018);
    result = sel.search(qry);
    show(result);
    assert(result.get_capacity() == 4);

    // Search for a non-matching boat
    qry.init("Fishing Boat", 0.0, 0, 0);
    result = sel.search(qry);
    show(result);
    assert(result.get_type() == "Unknown"); // Should return default boat

    return 0;
}
